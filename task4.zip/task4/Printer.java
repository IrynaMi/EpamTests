package task4;

public class Printer {
	static void print(Object message) {
		System.out.println(message);
	}

}
