package task4;

public class NaturalNumbers {
	
	static int findMaxDigit(int number) {
		int maxInt = number%10;
		number /=10;
		while(number > 0) {
			
			if(number%10 > maxInt) {
				maxInt = number%10;
			}
			number /= 10;
		}
		Printer.print(maxInt);
		return maxInt;
	}
	
	
	
	static boolean isPalindrome(int number){
		boolean isPalindrome = false;
		int next = 0;
		int palindrom = number;

		while (palindrom != 0){
			next = (next * 10) + (palindrom % 10);
			palindrom /= 10;
		}

		if (number == next){
			return true;
		}
		Printer.print(isPalindrome);
		return isPalindrome;
	}
	
	
	
	
	static boolean isNumberSimple (int number) {
		boolean isSimple = true;
		int counter = 0;
		for (int i = 1; i<=number; i++) {
			if (number%i == 0) {
				counter++;
			}
		}
		if (counter > 2) {
			isSimple = false;
		}
		Printer.print(isSimple);
		return false;
		
	}
	
	
	
	static StringBuilder findSimpleDividersOfNumber  (int number) {
		StringBuilder result = new StringBuilder();
		
		int j;
		int i;
		for (i = 1; i<=number; i++) {
			
			if (number%i==0) {
				
				int counter = 0;
				for(j=1; j<=i; j++) {
					
					if(i%j==0) {
						counter++;
					}
				}
				if (counter == 2) {
					result.append((j-1)+" ");
				}
			}
		}
		
		Printer.print(result);
		return result;
	}
	
	static int findNumOfUniqueDigits(int number) {
        int digits = 0;
        int count = 0;
        for (int digit = number % 10; number != 0; number /= 10, digit = number % 10) {
            int digitBit = 1 << digit;
            if ((digits & digitBit) == 0) {
                digits |= digitBit;
                count++;
            } 
        }
        Printer.print(count);
        return count;
    }

	
	
	
	public static int findNod(int a, int b) {
		int t;
		while (b != 0) {
			t = b;
			b = a % b;
			a = t;
		}
		return a;
	}
	
	

}
