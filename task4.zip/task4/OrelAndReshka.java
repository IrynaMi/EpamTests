package task4;

import java.util.Random;

public class OrelAndReshka {
	
	static void orelAndReshkaCounter () {
		final int OREL = 0;
		final int RANGE_OF_SIDES = 2;
		int orelCounter = 0;
		int reshkaCounter = 0;
		int i;
		for(i=0; i<1000; i++) {
			
			Random random = new Random();
			int randomSide = random.nextInt(RANGE_OF_SIDES);
			
			if (randomSide == OREL) {
				orelCounter++;
			}else {
				reshkaCounter++;
			}
		}
		Printer.print("Orel: " + orelCounter + " Reshka: " + reshkaCounter);
	}

}
