package task4;

public class PerfectNumber {
	
	public static boolean isNumberPerfect (int number) {
		boolean isPerfect = false;
		int sum = 0;
		for(int i = 1; i < number; i++) {
			if(number%i == 0) {
				sum +=i;
			}
		}
		if(sum == number) {
			isPerfect = true;
		}
		Printer.print(isPerfect);
		return isPerfect;
		
	}
}
