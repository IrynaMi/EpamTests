package task4;

public class Tester {

	public static void main(String[] args) {
		//OrelAndReshka.orelAndReshkaCounter();
		//NaturalNumbers.findMaxDigit(12334);
		//NaturalNumbers.isPalindrome(1231);
		//NaturalNumbers.isNumberSimple(14);
		//NaturalNumbers.findSimpleDividersOfNumber(50);
		//NaturalNumbers.findQuantityOfDifferntNumerals(1233);
		//NaturalNumbers.findNod(9, 12);
		NaturalNumbers.findNumOfUniqueDigits(1243445);
		//PerfectNumber.isNumberPerfect(496);
		
	}

}
